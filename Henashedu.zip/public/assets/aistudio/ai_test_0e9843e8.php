<?php
require_once __DIR__ . '/config.php';
header('Content-Type: text/plain; charset=utf-8');

if (!defined('AI_API_KEY') || AI_API_KEY === '' || AI_API_KEY === 'ضع_المفتاح_هنا') {
    exit("1) المفتاح غير مضاف في config.php (AI_API_KEY فارغ أو ما زال placeholder).\n");
}
echo "1) المفتاح مضاف (طوله " . strlen(AI_API_KEY) . " حرف).\n";

if (!function_exists('curl_init')) {
    exit("2) امتداد cURL غير متاح على الاستضافة، لذلك لا يمكن الاتصال بالـ API.\n");
}
echo "2) cURL متاح.\n";

$ch = curl_init('https://api.anthropic.com/v1/messages');
curl_setopt_array($ch, [
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => json_encode([
        'model' => 'claude-haiku-5-5',
        'max_tokens' => 50,
        'messages' => [['role' => 'user', 'content' => 'قل مرحبا']],
    ]),
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT        => 20,
    CURLOPT_HTTPHEADER     => [
        'Content-Type: application/json',
        'x-api-key: ' . AI_API_KEY,
        'anthropic-version: 2023-06-01',
    ],
]);
$body  = curl_exec($ch);
$code  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);
curl_close($ch);

echo "3) رمز الاستجابة: $code\n";
if ($body === false) {
    echo "4) خطأ الاتصال: $error\n";
} else {
    echo "4) الرد (أول 300 حرف): " . mb_substr((string)$body, 0, 300) . "\n";
}
