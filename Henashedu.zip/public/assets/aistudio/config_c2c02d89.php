<?php
declare(strict_types=1);

// ===== وضع التشخيص: خليه false على الاستضافة (true بس مؤقتاً لو في مشكلة) =====
const DEBUG = false;
if (DEBUG) {
    ini_set('display_errors', '1');
    error_reporting(E_ALL);
}

const APP_NAME       = 'منصة عائلة حنيش التعليمية';
const ADMIN_EMAIL    = 'admin@hanish.edu';
const ADMIN_PASSWORD = 'ضع_كلمة_سر_الأدمن_الجديدة'; // غيّرها من تبويب حسابي في لوحة الإدارة

// ===== قاعدة البيانات (من لوحة InfinityFree ← MySQL Databases) =====
const DB_HOST = 'sql303.infinityfree.com';
const DB_NAME = 'if0_43023184_gdb_hanish_db';
const DB_USER = 'if0_43023184';
const DB_PASS = 'Hanish20db782';
// ===== الذكاء الاصطناعي (Groq API) =====
const GROQ_API_KEY = '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';
const GROQ_MODEL   = 'llama-3.3-70b-versatile';

// مفاتيح بديلة (اختياري)
const GEMINI_API_KEY = 'ضع_المفتاح_هنا';
const GEMINI_MODEL   = 'gemini-2.5-flash';
const OPENAI_API_KEY = 'ضع_المفتاح_هنا';
const OPENAI_MODEL   = 'gpt-4o-mini';

// ===== الصوت الواقعي للمعلم (Azure Speech، اختياري) =====
const AZURE_SPEECH_KEY    = 'ضع_المفتاح_هنا';
const AZURE_SPEECH_REGION = 'westeurope';
const TTS_VOICE           = 'ar-EG-ShakirNeural';

const STAGES = [
    'المرحلة الابتدائية (الصفوف 1-6)',
    'المرحلة الإعدادية (الصفوف 1-3)',
    'المرحلة الثانوية (الصفوف 1-3)',
];

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function e(?string $s): string
{
    return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function check_csrf(): bool
{
    return isset($_POST['csrf'], $_SESSION['csrf'])
        && hash_equals($_SESSION['csrf'], (string)$_POST['csrf']);
}

function flash(string $title, string $text, bool $ok = true): void
{
    $_SESSION['flash'] = ['title' => $title, 'text' => $text, 'ok' => $ok];
}

function redirect_home(): void
{
    header('Location: index.php');
    exit;
}

// توافق مع إصدارات PHP الأقدم
if (!function_exists('str_contains')) {
    function str_contains(string $haystack, string $needle): bool
    {
        return $needle === '' || strpos($haystack, $needle) !== false;
    }
}