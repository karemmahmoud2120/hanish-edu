<?php
require_once __DIR__ . '/config.php';
header('Content-Type: text/plain; charset=utf-8');

if (!defined('GROQ_API_KEY') || GROQ_API_KEY === '' || GROQ_API_KEY === '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') {
    exit("1) GROQ_API_KEY غير مضاف في config.php.\n");
}
echo "1) المفتاح مضاف (طوله " . strlen(GROQ_API_KEY) . " حرف).\n";

$model = defined('GROQ_MODEL') ? GROQ_MODEL : 'llama-3.3-70b-versatile';
echo "2) النموذج: $model\n";

if (!function_exists('curl_init')) {
    exit("3) cURL غير متاح.\n");
}

$ch = curl_init('https://api.groq.com/openai/v1/chat/completions');
curl_setopt_array($ch, [
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => json_encode([
        'model' => $model,
        'max_tokens' => 50,
        'messages' => [['role' => 'user', 'content' => 'قل مرحبا']],
    ]),
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT        => 20,
    CURLOPT_HTTPHEADER     => [
        'Content-Type: application/json',
        'Authorization: Bearer ' . GROQ_API_KEY,
    ],
]);
$body  = curl_exec($ch);
$code  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);
curl_close($ch);

echo "3) رمز الاستجابة: $code\n";
echo $body === false ? "4) خطأ الاتصال: $error\n" : "4) الرد: " . mb_substr((string)$body, 0, 300) . "\n";
