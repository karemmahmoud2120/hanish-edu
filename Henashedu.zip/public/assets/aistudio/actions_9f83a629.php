<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !check_csrf()) {
    flash('خطأ', 'طلب غير صالح، حاول مرة أخرى.', false);
    header('Location: index.php');
    exit;
}

$action   = $_POST['action'] ?? '';
$now      = date('Y-m-d H:i:s');
$staff    = current_staff();
$tab      = preg_replace('/[^a-z]/', '', (string)($_POST['tab'] ?? 'overview'));
$redirect = 'index.php';

// صلاحية كل عملية إدارية: اسم الصلاحية، أو owner للمالك فقط، أو any لأي فريق
$adminActions = [
    'add_lesson' => 'lessons', 'bulk_lessons' => 'lessons', 'delete_lesson' => 'lessons',
    'add_news' => 'news', 'delete_news' => 'news',
    'add_link' => 'links', 'delete_link' => 'links',
    'add_user' => 'users', 'delete_user' => 'users', 'reset_user_password' => 'users',
    'save_hero' => 'site',
    'add_result' => 'grades', 'delete_result' => 'grades',
    'add_quiz' => 'exams', 'delete_quiz' => 'exams',
    'upload_exam_file' => 'exams', 'delete_exam_file' => 'exams',
    'upload_note' => 'notes', 'delete_note' => 'notes',
    'save_schedule' => 'site', 'delete_message' => 'messages', 'backup' => 'owner',
    'import_students' => 'users', 'update_user' => 'users', 'set_lesson_target' => 'lessons',
    'add_curriculum' => 'lessons', 'delete_curriculum' => 'lessons',
    'answer_question' => 'lessons', 'reject_question' => 'lessons', 'delete_question' => 'lessons', 'save_blocked_words' => 'lessons',
    'add_channel' => 'channels', 'delete_channel' => 'channels', 'sync_channels' => 'channels',
    'approve_video' => 'channels', 'reject_video' => 'channels', 'save_live_filter' => 'channels',
    'add_staff' => 'owner', 'update_staff' => 'owner', 'toggle_staff' => 'owner',
    'delete_staff' => 'owner', 'reset_staff_password' => 'owner',
    'save_ai_config' => 'owner', 'test_ai' => 'owner',
    'change_my_password' => 'any', 'logout_admin' => 'any',
];

if (isset($adminActions[$action])) {
    $need = $adminActions[$action];
    if ($need === 'any') {
        $allowed = $staff !== null;
    } elseif ($need === 'owner') {
        $allowed = $staff !== null && ($staff['is_owner'] ?? false);
    } else {
        $allowed = can($staff, $need);
    }
    if (!$allowed) {
        flash('غير مصرح', 'ليس لديك صلاحية لهذه العملية.', false);
        header('Location: admin.php');
        exit;
    }
    $redirect = 'admin.php?tab=' . $tab;
}

switch ($action) {

    case 'save_ai_config':
        $provider  = trim((string)($_POST['ai_provider'] ?? 'gemini'));
        $geminiKey = trim((string)($_POST['gemini_api_key'] ?? ''));
        $geminiMod = trim((string)($_POST['gemini_model'] ?? 'gemini-1.5-flash'));
        $groqKey   = trim((string)($_POST['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'] ?? ''));
        $groqMod   = trim((string)($_POST['llama-3.3-70b-versatile'] ?? 'llama-3.3-70b-versatile'));

        set_site_setting('ai_provider', $provider);
        set_site_setting('gemini_api_key', $geminiKey);
        set_site_setting('gemini_model', $geminiMod);
        set_site_setting('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', $groqKey);
        set_site_setting('llama-3.3-70b-versatile', $groqMod);

        // حفظ القيم في الجلسة لتحديث الاستجابة فوراً
        $_SESSION['ai_provider']    = $provider;
        $_SESSION['gemini_api_key'] = $geminiKey;
        $_SESSION['gemini_model']   = $geminiMod;
        $_SESSION['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']   = $groqKey;
        $_SESSION['llama-3.3-70b-versatile']     = $groqMod;

        flash('تم الحفظ', 'تم تحديث إعدادات الذكاء الاصطناعي بنجاح.');
        break;

    case 'test_ai':
        $prompt = trim((string)($_POST['prompt'] ?? ''));
        if ($prompt === '') {
            flash('تنبيه', 'الرجاء إدخال نص للاختبار.', false);
            break;
        }

        if (function_exists('ai_complete')) {
            $sys = "أنت مساعد ذكي لاختبار الخدمة في لوحة الإدارة. أجب باختصار شديد باللغة العربية.";
            $res = ai_complete($sys, $prompt);
            if ($res !== null) {
                flash('نجاح الاختبار 🤖', 'استجابة الذكاء الاصطناعي: ' . $res);
            } else {
                $err = !empty($GLOBALS['AI_LAST_ERROR']) ? implode(' | ', $GLOBALS['AI_LAST_ERROR']) : 'لم يتم الحصول على رد.';
                flash('فشل الاختبار ❌', 'تعذر الاتصال بالمزود. التفاصيل: ' . $err, false);
            }
        } else {
            flash('خطأ', 'دالة ai_complete غير معرفة.', false);
        }
        break;

    case 'register':
        $role  = $_POST['role'] ?? '';
        $name  = trim((string)($_POST['name'] ?? ''));
        $email = strtolower(trim((string)($_POST['email'] ?? '')));
        $pass  = (string)($_POST['password'] ?? '');

        if (!in_array($role, ['student', 'parent'], true) || $name === '' ||
            filter_var($email, FILTER_VALIDATE_EMAIL) === false || strlen($pass) < 6) {
            flash('بيانات غير صحيحة', 'تأكد من الاسم والبريد وأن كلمة المرور 6 أحرف على الأقل.', false);
            break;
        }

        $gradeName = null;
        if ($role === 'student') {
            $stageRaw = (string)($_POST['stage'] ?? '');
            $yearRaw  = (string)($_POST['year'] ?? '');
            if (!ctype_digit($stageRaw) || !ctype_digit($yearRaw) ||
                !isset(GRADE_YEARS[(int)$stageRaw][(int)$yearRaw])) {
                flash('بيانات غير مكتملة', 'اختر المرحلة الدراسية ثم السنة الدراسية.', false);
                break;
            }
            $gradeName = GRADE_YEARS[(int)$stageRaw][(int)$yearRaw];
        }

        $stmt = db()->prepare('SELECT 1 FROM users WHERE email = ?');
        $stmt->execute([$email]);
        if ($stmt->fetchColumn()) {
            flash('البريد مستخدم', 'هذا البريد مسجل بالفعل، جرب تسجيل الدخول.', false);
            break;
        }

        $linkCode = $role === 'student' ? generate_link_code() : null;
        db()->prepare('INSERT INTO users (role, name, email, password_hash, grade, link_code, created_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?)')
            ->execute([$role, mb_substr($name, 0, 100), $email, password_hash($pass, PASSWORD_DEFAULT),
                       $gradeName, $linkCode, $now]);

        session_regenerate_id(true);
        $_SESSION['user_id'] = (int)db()->lastInsertId();
        if ($role === 'student') {
            $redirect = 'student.php';
        }
        flash('أهلاً بك!', $role === 'student'
            ? 'تم إنشاء حسابك في ' . $gradeName . '. كود الربط الخاص بك: ' . $linkCode . ' (أعطه لولي أمرك)'
            : 'تم إنشاء حسابك بنجاح. اربط أبناءك من لوحتك بكود الطالب.');
        break;

    case 'login_role':
        $email = strtolower(trim((string)($_POST['email'] ?? '')));
        $pass  = (string)($_POST['password'] ?? '');
        $stmt = db()->prepare('SELECT * FROM users WHERE email = ?');
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        if ($user && password_verify($pass, $user['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['user_id'] = (int)$user['id'];
            if ($user['role'] === 'student') {
                $redirect = 'student.php';
            }
            flash('مرحباً بك!', 'تم تسجيل دخولك بنجاح.');
        } else {
            flash('خطأ في تسجيل الدخول', 'البريد الإلكتروني أو كلمة المرور غير صحيحة.', false);
        }
        break;

    case 'login_admin':
        $redirect = 'admin.php';
        $email = strtolower(trim((string)($_POST['email'] ?? '')));
        $pass  = (string)($_POST['password'] ?? '');
        $stmt = db()->prepare('SELECT * FROM staff WHERE email = ? AND active = 1');
        $stmt->execute([$email]);
        $s = $stmt->fetch();
        if ($s && password_verify($pass, $s['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['staff_id'] = (int)$s['id'];
            flash('مرحباً ' . $s['name'], 'تم الدخول إلى لوحة الإدارة.');
        } else {
            flash('خطأ في الدخول', 'البريد أو كلمة المرور غير صحيحة.', false);
        }
        break;

    case 'logout':
        unset($_SESSION['user_id']);
        flash('تم تسجيل الخروج', 'تم تسجيل خروجك بأمان.');
        break;

    case 'logout_admin':
        unset($_SESSION['staff_id']);
        $redirect = 'admin.php';
        flash('تم تسجيل الخروج', 'تم الخروج من لوحة الإدارة.');
        break;

    case 'change_my_password':
        $current = (string)($_POST['current'] ?? '');
        $new     = (string)($_POST['new'] ?? '');
        $stmt = db()->prepare('SELECT password_hash FROM staff WHERE id = ?');
        $stmt->execute([(int)$staff['id']]);
        $hash = $stmt->fetchColumn();

        if (!$hash || !password_verify($current, $hash)) {
            flash('خطأ', 'كلمة المرور الحالية غير صحيحة.', false);
        } elseif (strlen($new) < 6) {
            flash('خطأ', 'كلمة المرور الجديدة يجب أن تكون 6 أحرف على الأقل.', false);
        } else {
            db()->prepare('UPDATE staff SET password_hash = ? WHERE id = ?')
                ->execute([password_hash($new, PASSWORD_DEFAULT), (int)$staff['id']]);
            flash('تم التغيير', 'تم تغيير كلمة المرور بنجاح.');
        }
        break;

    case 'save_hero':
        $mode = (string)($_POST['mode'] ?? 'animated');
        if (!in_array($mode, ['animated', 'image', 'video'], true)) {
            flash('خطأ', 'نوع الخلفية غير معروف.', false);
            break;
        }

        if ($mode === 'animated') {
            set_site_setting('hero_mode', 'animated');
            flash('تم الحفظ', 'الخلفية الآن: الحركة المتحركة.');
            break;
        }

        $media   = site_setting('hero_media', '');
        $file    = $_FILES['media'] ?? null;
        $urlIn   = trim((string)($_POST['media_url'] ?? ''));
        $allowed = $mode === 'image' ? ['jpg', 'jpeg', 'png', 'webp'] : ['mp4', 'webm'];

        if ($file && ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
            if ($file['error'] !== UPLOAD_ERR_OK) {
                flash('فشل الرفع', 'الملف أكبر من المسموح به على الاستضافة، جرّب ملفاً أصغر أو استخدم رابطاً مباشراً.', false);
                break;
            }
            $ext = strtolower(pathinfo((string)$file['name'], PATHINFO_EXTENSION));
            if (!in_array($ext, $allowed, true) || $file['size'] > 15 * 1024 * 1024) {
                flash('ملف غير مدعوم', 'الصيغ المسموحة: ' . implode('، ', $allowed) . ' وبحد أقصى 15 ميجا.', false);
                break;
            }
            $dir = __DIR__ . '/uploads';
            if (!is_dir($dir) && !mkdir($dir, 0755, true)) {
                flash('خطأ', 'تعذر إنشاء مجلد الرفع على الاستضافة.', false);
                break;
            }
            $name = 'hero-' . bin2hex(random_bytes(6)) . '.' . $ext;
            if (!move_uploaded_file($file['tmp_name'], $dir . '/' . $name)) {
                flash('خطأ', 'تعذر حفظ الملف على الخادم.', false);
                break;
            }
            $media = 'uploads/' . $name;
        } elseif ($urlIn !== '') {
            if (filter_var($urlIn, FILTER_VALIDATE_URL) === false || !preg_match('#^https://#i', $urlIn)) {
                flash('رابط غير صحيح', 'استخدم رابطاً مباشراً يبدأ بـ https://', false);
                break;
            }
            $media = $urlIn;
        } elseif ($media === '') {
            flash('لا يوجد ملف', 'ارفع صورة أو فيديو، أو ضع رابطاً مباشراً.', false);
            break;
        }

        set_site_setting('hero_mode', $mode);
        set_site_setting('hero_media', $media);
        flash('تم الحفظ', 'تم تحديث خلفية الواجهة الرئيسية.');
        break;

    case 'add_lesson':
        $title   = trim((string)($_POST['title'] ?? ''));
        $subject = trim((string)($_POST['subject'] ?? ''));
        $video   = trim((string)($_POST['video'] ?? ''));
        $desc    = trim((string)($_POST['description'] ?? ''));
        $range   = target_range((string)($_POST['target'] ?? ''));
        if ($title === '' || $subject === '' || $desc === '' || !$range ||
            filter_var($video, FILTER_VALIDATE_URL) === false) {
            flash('بيانات غير مكتملة', 'تأكد من تعبئة كل الحقول واختيار المرحلة وصحة الرابط.', false);
            break;
        }
        db()->prepare('INSERT INTO lessons (title, stage, subject, description, video, grades, created_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?)')
            ->execute([mb_substr($title, 0, 200), stage_of_grade($range[0]), mb_substr($subject, 0, 100),
                       mb_substr($desc, 0, 1000), $video, implode(',', $range), date('Y-m-d')]);
        flash('تم النشر', 'تم إضافة الدرس وظهر فوراً للصفوف المحددة.');
        break;

    case 'delete_lesson':
        db()->prepare('DELETE FROM lessons WHERE id = ?')->execute([(int)($_POST['id'] ?? 0)]);
        flash('تم الحذف', 'تم حذف الدرس.');
        break;

    case 'bulk_lessons':
        $raw   = (string)($_POST['lines'] ?? '');
        $lines = array_values(array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $raw)), fn($l) => $l !== ''));
        $lines = array_slice($lines, 0, 200);

        $added  = 0;
        $errors = [];
        $check  = db()->prepare('SELECT 1 FROM lessons WHERE video = ?');
        $ins    = db()->prepare('INSERT INTO lessons (title, stage, subject, description, video, created_at) VALUES (?, ?, ?, ?, ?, ?)');

        foreach ($lines as $no => $line) {
            $parts = array_map('trim', explode('|', $line, 5));
            if (count($parts) < 4) {
                $errors[] = 'سطر ' . ($no + 1) . ': عدد الأجزاء أقل من 4';
                continue;
            }
            [$stageText, $subject, $title, $url] = $parts;
            $desc = $parts[4] ?? '';

            $stage = null;
            if (str_contains($stageText, 'ابتدائ')) {
                $stage = STAGES[0];
            } elseif (str_contains($stageText, 'إعدادي') || str_contains($stageText, 'اعدادي')) {
                $stage = STAGES[1];
            } elseif (str_contains($stageText, 'ثانوي')) {
                $stage = STAGES[2];
            }

            if ($stage === null || $subject === '' || $title === '' || filter_var($url, FILTER_VALIDATE_URL) === false) {
                $errors[] = 'سطر ' . ($no + 1) . ': مرحلة أو مادة أو عنوان أو رابط غير صحيح';
                continue;
            }

            $check->execute([$url]);
            if ($check->fetchColumn()) {
                $errors[] = 'سطر ' . ($no + 1) . ': الرابط موجود بالفعل';
                continue;
            }

            $ins->execute([mb_substr($title, 0, 200), $stage, mb_substr($subject, 0, 100),
                           mb_substr($desc !== '' ? $desc : $title, 0, 1000), $url, date('Y-m-d')]);
            $added++;
        }

        $msg = 'تمت إضافة ' . $added . ' درس.';
        if ($errors) {
            $msg .= ' تم تخطي ' . count($errors) . ' سطر: ' . implode(' | ', array_slice($errors, 0, 3));
        }
        flash($added > 0 ? 'تم الاستيراد' : 'لم يُضف شيء', $msg, $added > 0);
        break;

    case 'add_result':
        $sid     = (int)($_POST['student_id'] ?? 0);
        $subject = trim((string)($_POST['subject'] ?? ''));
        $title   = trim((string)($_POST['title'] ?? ''));
        $score   = $_POST['score'] ?? '';
        $max     = $_POST['max_score'] ?? '100';
        $date    = (string)($_POST['exam_date'] ?? '');
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
            $date = date('Y-m-d');
        }
        if ($subject === '' || $title === '' || !is_numeric($score) || !is_numeric($max) ||
            (float)$max <= 0 || (float)$score < 0 || (float)$score > (float)$max) {
            flash('بيانات غير صحيحة', 'تأكد من المادة والاختبار، وأن الدرجة بين صفر والدرجة النهائية.', false);
            break;
        }
        $chk = db()->prepare("SELECT 1 FROM users WHERE id = ? AND role = 'student'");
        $chk->execute([$sid]);
        if (!$chk->fetchColumn()) {
            flash('طالب غير موجود', 'اختر طالباً من القائمة.', false);
            break;
        }
        db()->prepare('INSERT INTO exam_results (student_id, subject, title, score, max_score, exam_date, created_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?)')
            ->execute([$sid, mb_substr($subject, 0, 100), mb_substr($title, 0, 200),
                       (float)$score, (float)$max, $date, $now]);
        flash('تمت الإضافة', 'تم تسجيل النتيجة، وستظهر لولي الأمر فوراً.');
        break;

    case 'delete_result':
        db()->prepare('DELETE FROM exam_results WHERE id = ?')->execute([(int)($_POST['id'] ?? 0)]);
        flash('تم الحذف', 'تم حذف النتيجة.');
        break;

    case 'add_quiz':
        $title   = trim((string)($_POST['title'] ?? ''));
        $subject = trim((string)($_POST['subject'] ?? ''));
        $range   = target_range((string)($_POST['target'] ?? ''));
        $raw     = (string)($_POST['questions'] ?? '');
        if ($title === '' || $subject === '' || !$range) {
            flash('بيانات غير مكتملة', 'اكتب العنوان والمادة واختر المرحلة.', false);
            break;
        }
        $lines = array_values(array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $raw)), fn($l) => $l !== ''));
        $valid = [];
        $bad   = 0;
        foreach ($lines as $line) {
            $p = array_map('trim', explode('|', $line, 6));
            if (count($p) === 6 && $p[0] !== '' && $p[1] !== '' && $p[2] !== '' && $p[3] !== '' && $p[4] !== '' &&
                $p[5] !== '' && ctype_digit($p[5]) && (int)$p[5] >= 1 && (int)$p[5] <= 4) {
                $valid[] = $p;
            } else {
                $bad++;
            }
        }
        if (!$valid) {
            flash('لا توجد أسئلة صحيحة', 'أضف سؤالاً واحداً على الأقل بخياراته الأربعة والإجابة الصحيحة.', false);
            break;
        }
        $pdo = db();
        $pdo->prepare('INSERT INTO quizzes (title, subject, stage, grades, created_at) VALUES (?, ?, ?, ?, ?)')
            ->execute([mb_substr($title, 0, 200), mb_substr($subject, 0, 100), stage_of_grade($range[0]),
                       implode(',', $range), $now]);
        $quizId = (int)$pdo->lastInsertId();
        $qins = $pdo->prepare('INSERT INTO quiz_questions (quiz_id, question, opt1, opt2, opt3, opt4, correct) VALUES (?, ?, ?, ?, ?, ?, ?)');
        foreach (array_slice($valid, 0, 100) as $p) {
            $qins->execute([$quizId, mb_substr($p[0], 0, 1000), mb_substr($p[1], 0, 255), mb_substr($p[2], 0, 255),
                            mb_substr($p[3], 0, 255), mb_substr($p[4], 0, 255), (int)$p[5]]);
        }
        flash('تم إنشاء الامتحان', 'تمت إضافة ' . count($valid) . ' سؤال' . ($bad ? ' وتم تخطي ' . $bad . ' سطر غير صحيح.' : '.'));
        break;

    case 'delete_quiz':
        db()->prepare('DELETE FROM quizzes WHERE id = ?')->execute([(int)($_POST['id'] ?? 0)]);
        flash('تم الحذف', 'تم حذف الامتحان.');
        break;

    case 'submit_quiz':
        $redirect = 'student.php?sec=exams';
        $user = current_user();
        if (!$user || $user['role'] !== 'student') {
            flash('غير مصرح', 'هذه الخدمة للطلاب فقط.', false);
            break;
        }
        $quizId  = (int)($_POST['quiz_id'] ?? 0);
        $answers = (array)($_POST['answers'] ?? []);
        $pdo = db();

        $stmt = $pdo->prepare('SELECT * FROM quizzes WHERE id = ?');
        $stmt->execute([$quizId]);
        $quiz = $stmt->fetch();
        if (!$quiz || !item_visible_to($quiz, $user['grade'])) {
            flash('غير متاح', 'هذا الامتحان غير متاح لمرحلتك.', false);
            break;
        }

        $stmt = $pdo->prepare('SELECT 1 FROM quiz_attempts WHERE quiz_id = ? AND student_id = ?');
        $stmt->execute([$quizId, (int)$user['id']]);
        if ($stmt->fetchColumn()) {
            flash('سبق أن أديت هذا الامتحان', 'لا يمكن إعادة الامتحان.', false);
            break;
        }

        $stmt = $pdo->prepare('SELECT id, correct FROM quiz_questions WHERE quiz_id = ?');
        $stmt->execute([$quizId]);
        $questions = $stmt->fetchAll();
        $total = count($questions);
        if ($total === 0) {
            flash('لا توجد أسئلة', 'هذا الامتحان ليس به أسئلة بعد.', false);
            break;
        }

        $score = 0;
        foreach ($questions as $q) {
            if (isset($answers[$q['id']]) && (int)$answers[$q['id']] === (int)$q['correct']) {
                $score++;
            }
        }

        $pdo->prepare('INSERT INTO quiz_attempts (quiz_id, student_id, score, total, created_at) VALUES (?, ?, ?, ?, ?)')
            ->execute([$quizId, (int)$user['id'], $score, $total, $now]);
        $pdo->prepare('INSERT INTO exam_results (student_id, subject, title, score, max_score, exam_date, created_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?)')
            ->execute([(int)$user['id'], $quiz['subject'], $quiz['title'], $score, $total, date('Y-m-d'), $now]);

        flash('تم تسليم الامتحان', 'نتيجتك: ' . $score . ' من ' . $total . '، وتمت إضافتها إلى نتائجك.');
        break;

    case 'change_user_password':
        $redirect = 'student.php?sec=account';
        $user = current_user();
        if (!$user) {
            flash('غير مصرح', 'سجّل الدخول أولاً.', false);
            break;
        }
        $current = (string)($_POST['current'] ?? '');
        $new     = (string)($_POST['new'] ?? '');
        $stmt = db()->prepare('SELECT password_hash FROM users WHERE id = ?');
        $stmt->execute([(int)$user['id']]);
        $hash = $stmt->fetchColumn();
        if (!$hash || !password_verify($current, $hash)) {
            flash('خطأ', 'كلمة المرور الحالية غير صحيحة.', false);
        } elseif (strlen($new) < 6) {
            flash('خطأ', 'كلمة المرور الجديدة يجب أن تكون 6 أحرف على الأقل.', false);
        } else {
            db()->prepare('UPDATE users SET password_hash = ? WHERE id = ?')
                ->execute([password_hash($new, PASSWORD_DEFAULT), (int)$user['id']]);
            flash('تم التغيير', 'تم تغيير كلمة المرور بنجاح.');
        }
        break;

    case 'upload_exam_file':
        $range   = target_range((string)($_POST['target'] ?? ''));
        $subject = trim((string)($_POST['subject'] ?? ''));
        $title   = trim((string)($_POST['title'] ?? ''));
        if (!$range || $subject === '' || $title === '') {
            flash('بيانات غير مكتملة', 'اختر المرحلة واكتب المادة واسم الامتحان.', false);
            break;
        }
        $file = $_FILES['exam_file'] ?? null;
        if (!$file || ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            flash('فشل الرفع', 'اختر ملفاً. وتأكد أنه أقل من الحد المسموح على الاستضافة.', false);
            break;
        }
        $ext = strtolower(pathinfo((string)$file['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['pdf', 'doc', 'docx'], true) || $file['size'] > 200 * 1024 * 1024) {
            flash('ملف غير مدعوم', 'الصيغ المسموحة: PDF و DOC و DOCX، بحد أقصى 200 ميجا.', false);
            break;
        }
        $dir = __DIR__ . '/uploads/exams';
        if (!ensure_upload_dir($dir)) {
            flash('خطأ', 'تعذر تجهيز مجلد الرفع على الاستضافة.', false);
            break;
        }
        $name = 'exam-' . bin2hex(random_bytes(8)) . '.' . $ext;
        if (!move_uploaded_file($file['tmp_name'], $dir . '/' . $name)) {
            flash('خطأ', 'تعذر حفظ الملف على الخادم.', false);
            break;
        }
        db()->prepare('INSERT INTO exam_files (stage, subject, title, file_path, file_type, grades, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
            ->execute([stage_of_grade($range[0]), mb_substr($subject, 0, 100), mb_substr($title, 0, 200),
                       'uploads/exams/' . $name, $ext, implode(',', $range), $now]);
        flash('تم الرفع', 'تم رفع الامتحان، وسيظهر للطلاب في الصفوف المحددة.');
        break;

    case 'delete_exam_file':
        $stmt = db()->prepare('SELECT file_path FROM exam_files WHERE id = ?');
        $stmt->execute([(int)($_POST['id'] ?? 0)]);
        $path = $stmt->fetchColumn();
        if ($path) {
            $full = __DIR__ . '/' . $path;
            if (is_file($full)) {
                unlink($full);
            }
            db()->prepare('DELETE FROM exam_files WHERE id = ?')->execute([(int)($_POST['id'] ?? 0)]);
        }
        flash('تم الحذف', 'تم حذف ملف الامتحان.');
        break;

    case 'add_channel':
        $title   = trim((string)($_POST['title'] ?? ''));
        $chId    = trim((string)($_POST['channel_id'] ?? ''));
        $stageI  = (string)($_POST['stage'] ?? '');
        $subject = trim((string)($_POST['subject'] ?? ''));
        if ($title === '' || $subject === '' || !preg_match('/^UC[A-Za-z0-9_-]{22}$/', $chId) ||
            !ctype_digit($stageI) || !isset(STAGES[(int)$stageI])) {
            flash('بيانات غير صحيحة', 'تأكد من الاسم والمادة والمرحلة، ومعرف القناة يبدأ بـ UC ويكون 24 حرفاً.', false);
            break;
        }
        $chk = db()->prepare('SELECT 1 FROM channels WHERE channel_id = ?');
        $chk->execute([$chId]);
        if ($chk->fetchColumn()) {
            flash('القناة مضافة', 'هذه القناة موجودة بالفعل.', false);
            break;
        }
        db()->prepare('INSERT INTO channels (title, channel_id, stage, subject, active, created_at) VALUES (?, ?, ?, ?, 1, ?)')
            ->execute([mb_substr($title, 0, 200), $chId, STAGES[(int)$stageI], mb_substr($subject, 0, 100), $now]);
        flash('تمت الإضافة', 'تمت إضافة القناة. اضغط تحديث الآن لجلب فيديوهاتها.');
        break;

    case 'delete_channel':
        db()->prepare('DELETE FROM channels WHERE id = ?')->execute([(int)($_POST['id'] ?? 0)]);
        flash('تم الحذف', 'تم حذف القناة وفيديوهاتها المعلقة.');
        break;

    case 'sync_channels':
        set_time_limit(90);
        $words    = live_filter_words();
        $pdo      = db();
        $channels = $pdo->query('SELECT * FROM channels WHERE active = 1')->fetchAll();
        $ins      = $pdo->prepare('INSERT IGNORE INTO pending_videos
                                  (channel_row, video_id, title, description, thumb, url, published, status, created_at)
                                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
        $inLessons = $pdo->prepare('SELECT 1 FROM lessons WHERE video = ?');
        $touch    = $pdo->prepare('UPDATE channels SET last_checked = ? WHERE id = ?');

        $added = 0; $skippedLive = 0; $failed = 0;
        foreach ($channels as $ch) {
            $items = fetch_channel_feed($ch['channel_id']);
            if (!$items) {
                $failed++;
                continue;
            }
            foreach ($items as $it) {
                if (is_live_title($it['title'], $words)) {
                    $skippedLive++;
                    continue;
                }
                $url = 'https://www.youtube.com/watch?v=' . $it['video_id'];
                $inLessons->execute([$url]);
                if ($inLessons->fetchColumn()) {
                    continue;
                }
                $ins->execute([(int)$ch['id'], $it['video_id'], mb_substr($it['title'], 0, 300),
                               mb_substr($it['description'], 0, 1000), $it['thumb'], $url,
                               $it['published'], 'pending', $now]);
                if ($ins->rowCount() > 0) {
                    $added++;
                }
            }
            $touch->execute([$now, (int)$ch['id']]);
        }

        $msg = 'تمت إضافة ' . $added . ' فيديو للمراجعة، وتم استبعاد ' . $skippedLive . ' بث مباشر.';
        if ($failed) {
            $msg .= ' تعذر تحديث ' . $failed . ' قناة.';
        }
        flash('تم التحديث', $msg);
        break;

    case 'approve_video':
        $pdo = db();
        $stmt = $pdo->prepare('SELECT p.*, c.stage, c.subject FROM pending_videos p
                               JOIN channels c ON c.id = p.channel_row WHERE p.id = ?');
        $stmt->execute([(int)($_POST['id'] ?? 0)]);
        $v = $stmt->fetch();
        if (!$v) {
            flash('غير موجود', 'هذا الفيديو لم يعد موجوداً.', false);
            break;
        }
        $desc = trim((string)$v['description']) !== '' ? $v['description'] : $v['title'];
        $pdo->prepare('INSERT INTO lessons (title, stage, subject, description, video, created_at) VALUES (?, ?, ?, ?, ?, ?)')
            ->execute([mb_substr($v['title'], 0, 200), $v['stage'], $v['subject'], mb_substr($desc, 0, 1000), $v['url'], date('Y-m-d')]);
        $pdo->prepare("UPDATE pending_videos SET status = 'approved' WHERE id = ?")->execute([(int)$v['id']]);
        flash('تم النشر', 'تم اعتماد الفيديو ونشره كدرس في المرحلة والمادة المحددة.');
        break;

    case 'reject_video':
        db()->prepare("UPDATE pending_videos SET status = 'rejected' WHERE id = ?")->execute([(int)($_POST['id'] ?? 0)]);
        flash('تم الرفض', 'تم استبعاد الفيديو.');
        break;

    case 'save_live_filter':
        $raw   = (string)($_POST['words'] ?? '');
        $words = array_filter(array_map(fn($w) => mb_substr(trim($w), 0, 50), preg_split('/[,\n]/', $raw)));
        set_site_setting('live_filter_words', implode(',', array_unique($words)));
        flash('تم الحفظ', 'تم تحديث كلمات فلتر البث المباشر.');
        break;

    case 'upload_note':
        $range   = target_range((string)($_POST['target'] ?? ''));
        $subject = trim((string)($_POST['subject'] ?? ''));
        $title   = trim((string)($_POST['title'] ?? ''));
        if (!$range || $subject === '' || $title === '') {
            flash('بيانات غير مكتملة', 'اختر المرحلة أو الصف واكتب المادة والعنوان.', false);
            break;
        }
        $file = $_FILES['note_file'] ?? null;
        if (!$file || ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            flash('فشل الرفع', 'اختر ملفاً. وتأكد أنه أقل من الحد المسموح على الاستضافة.', false);
            break;
        }
        $ext = strtolower(pathinfo((string)$file['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['pdf', 'doc', 'docx', 'ppt', 'pptx'], true) || $file['size'] > 200 * 1024 * 1024) {
            flash('ملف غير مدعوم', 'الصيغ المسموحة: PDF و DOC و DOCX و PPT و PPTX، بحد أقصى 200 ميجا.', false);
            break;
        }
        $dir = __DIR__ . '/uploads/notes';
        if (!ensure_upload_dir($dir)) {
            flash('خطأ', 'تعذر تجهيز مجلد الرفع على الاستضافة.', false);
            break;
        }
        $name = 'note-' . bin2hex(random_bytes(8)) . '.' . $ext;
        if (!move_uploaded_file($file['tmp_name'], $dir . '/' . $name)) {
            flash('خطأ', 'تعذر حفظ الملف على الخادم.', false);
            break;
        }
        db()->prepare('INSERT INTO notes (stage, subject, title, file_path, file_type, grades, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
            ->execute([stage_of_grade($range[0]), mb_substr($subject, 0, 100), mb_substr($title, 0, 200),
                       'uploads/notes/' . $name, $ext, implode(',', $range), $now]);
        flash('تم الرفع', 'تم رفع المذكرة، وستظهر للطلاب في الصف أو المرحلة المحددة.');
        break;

    case 'delete_note':
        $stmt = db()->prepare('SELECT file_path FROM notes WHERE id = ?');
        $stmt->execute([(int)($_POST['id'] ?? 0)]);
        $path = $stmt->fetchColumn();
        if ($path) {
            $full = __DIR__ . '/' . $path;
            if (is_file($full)) {
                unlink($full);
            }
            db()->prepare('DELETE FROM notes WHERE id = ?')->execute([(int)($_POST['id'] ?? 0)]);
        }
        flash('تم الحذف', 'تم حذف الملف.');
        break;

    case 'save_schedule':
        $sched = (array)($_POST['sched'] ?? []);
        foreach (STAGES as $i => $st) {
            $txt = trim((string)($sched[$i] ?? ''));
            set_site_setting('schedule_' . $i, mb_substr($txt, 0, 4000));
        }
        flash('تم الحفظ', 'تم تحديث الجداول الدراسية.');
        break;

    case 'send_message':
        $redirect = 'index.php#sections';
        $name  = trim((string)($_POST['name'] ?? ''));
        $email = strtolower(trim((string)($_POST['email'] ?? '')));
        $msg   = trim((string)($_POST['message'] ?? ''));
        if ($name === '' || filter_var($email, FILTER_VALIDATE_EMAIL) === false || $msg === '') {
            flash('بيانات غير مكتملة', 'اكتب اسمك وبريداً صحيحاً ونص الرسالة.', false);
            break;
        }
        db()->prepare('INSERT INTO messages (name, email, message, created_at) VALUES (?, ?, ?, ?)')
            ->execute([mb_substr($name, 0, 100), $email, mb_substr($msg, 0, 2000), $now]);
        flash('تم الإرسال', 'وصلت رسالتك للإدارة، وهنرد عليك قريباً.');
        break;

    case 'delete_message':
        db()->prepare('DELETE FROM messages WHERE id = ?')->execute([(int)($_POST['id'] ?? 0)]);
        flash('تم الحذف', 'تم حذف الرسالة.');
        break;

    case 'backup':
        $sql   = build_sql_dump();
        $fname = 'hanish-backup-' . date('Y-m-d-His');
        if (class_exists('ZipArchive')) {
            $tmp = tempnam(sys_get_temp_dir(), 'bkp');
            $zip = new ZipArchive();
            if ($zip->open($tmp, ZipArchive::OVERWRITE) === true) {
                $zip->addFromString('database.sql', $sql);
                $uploadsDir = __DIR__ . '/uploads';
                if (is_dir($uploadsDir)) {
                    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($uploadsDir, FilesystemIterator::SKIP_DOTS));
                    foreach ($it as $f) {
                        if ($f->isFile()) {
                            $rel = 'uploads/' . str_replace('\\', '/', substr($f->getPathname(), strlen($uploadsDir) + 1));
                            $zip->addFile($f->getPathname(), $rel);
                        }
                    }
                }
                $zip->close();
                header('Content-Type: application/zip');
                header('Content-Disposition: attachment; filename="' . $fname . '.zip"');
                header('Content-Length: ' . filesize($tmp));
                readfile($tmp);
                unlink($tmp);
                exit;
            }
        }
        header('Content-Type: application/sql; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $fname . '.sql"');
        echo $sql;
        exit;

    default:
        flash('خطأ', 'إجراء غير معروف.', false);
        break;
}

header('Location: ' . $redirect);
exit;